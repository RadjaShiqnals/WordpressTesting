<?php
/**
 * Admin Footer
 *
 * @package     EDD
 * @subpackage  Admin/Footer
 * @copyright   Copyright (c) 2018, Easy Digital Downloads, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.0
 */

// Exit if accessed directly.
